package admin.services;

import java.util.Random;

import admin.model.New_employee;

public class IT_support {
	
//	New_employee employee = new New_employee();
	
	public String generatePassword() {
		String chars = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghi" 
						+"jklmnopqrstuvwxyz!@#$%&";
		Random rnd = new Random();
		StringBuilder sb = new StringBuilder(8);
		for (int i = 0; i < 8; i++) {
			sb.append(chars.charAt(rnd.nextInt(chars.length())));
		}
			
		return sb.toString();
	}
	
	public String generateEmailAddress(Object employee, String userSelect) {

		return ( ((New_employee) employee).get_firstName().toLowerCase() + ((New_employee) employee).get_lastName().toLowerCase() +   "@" + userSelect.toLowerCase() + ".company" + ".com");
	}
	
	public void showCredentials(Object employee, String userSelect) {
		System.out.println("EMAIL ADDRESS ------>" + generateEmailAddress(employee, userSelect));
		System.out.println("PASSWORD ------>" + generatePassword());
	}
}
