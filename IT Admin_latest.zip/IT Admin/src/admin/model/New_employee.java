package admin.model;

import java.util.Scanner;

public class New_employee {
	
	private String firstName;
	private String lastName;
	
//	default constructor is created
	public New_employee() {
		Scanner s = new Scanner(System.in);
		System.out.println("******Enter New Joinee Details******");
		
		System.out.print("Please Enter First Name:");
		firstName = s.nextLine();
		
		System.out.print("Please Enter Last Name:");
		lastName = s.nextLine();
		set_firstName(firstName);
		set_lastName(lastName);
	}
	
//	getter for both values
	public String get_firstName() {
		return this.firstName;
	}
	
	public String get_lastName() {
		return this.lastName;
	}
	
//setter method	for both values
	public void set_firstName(String firstName) {
		this.firstName = firstName;
	}
	
	public void set_lastName(String lastName) {
		this.lastName = lastName;
	}
}
